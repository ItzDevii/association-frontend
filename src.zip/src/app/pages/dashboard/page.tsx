'use client';

import { Card } from 'primereact/card';
import { Chart } from 'primereact/chart';
import { useEffect, useState } from 'react';
import { getAllMembers } from '@/services/memberService';
import { getAllCotisations } from '@/services/cotisationService';
import { getAllActivities } from '@/services/activityService';

export default function DashboardPage() {
  const [totalMembers, setTotalMembers] = useState(0);
  const [totalCotisations, setTotalCotisations] = useState(0);
  const [totalActivities, setTotalActivities] = useState(0);

  const [chartData, setChartData] = useState({});
  const [chartOptions, setChartOptions] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const members = await getAllMembers();
      const cotisations = await getAllCotisations();
      const activities = await getAllActivities();

      setTotalMembers(members.length);
      setTotalCotisations(
        cotisations.reduce((sum, c) => sum + c.amount, 0)
      );
      setTotalActivities(activities.length);

      const monthlyTotals = Array(12).fill(0);
      cotisations.forEach(c => {
        const month = new Date(c.paymentDate).getMonth(); // ✅ corrected field
        monthlyTotals[month] += c.amount;
      });

      setChartData({
        labels: [
          'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        ],
        datasets: [
          {
            label: 'Cotisations (MAD)',
            data: monthlyTotals,
            backgroundColor: '#0d6efd',
          },
        ],
      });

      setChartOptions({
        responsive: true,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
          tooltip: {
            callbacks: {
              label: (context: any) =>
                `${context.dataset.label}: ${context.raw.toLocaleString()} MAD`,
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: (value: number | string) => `${value} MAD`,
            },
          },
        },
      });
    };

    fetchData();
  }, []);

  return (
    <div className="container-fluid">
      <h2 className="mb-4">Dashboard</h2>

      <div className="row mb-4">
        <div className="col-md-4 mb-3">
          <Card title="Total Members" className="text-center">
            <h3>{totalMembers}</h3>
          </Card>
        </div>
        <div className="col-md-4 mb-3">
          <Card title="Total Cotisations" className="text-center">
            <h3>{totalCotisations.toLocaleString()} MAD</h3>
          </Card>
        </div>
        <div className="col-md-4 mb-3">
          <Card title="Total Activities" className="text-center">
            <h3>{totalActivities}</h3>
          </Card>
        </div>
      </div>

      <div className="card mb-4 p-4">
        <h5 className="mb-3">Cotisations by Month</h5>
        <Chart type="bar" data={chartData} options={chartOptions} />
      </div>
    </div>
  );
}