'use client';

import ParticipationList from '@/components/participations/ParticipationList';

export default function ParticipationsPage() {
  return (
    <div>
      <ParticipationList />
    </div>
  );
}