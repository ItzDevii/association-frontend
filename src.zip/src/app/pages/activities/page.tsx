'use client';

import ActivityList from '@/components/activities/ActivityList';

export default function ActivitiesPage() {
  return (
    <div>
      <ActivityList />
    </div>
  );
}