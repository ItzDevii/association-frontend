'use client';

import DocumentList from '@/components/documents/DocumentList';

export default function DocumentsPage() {
  return (
    <div>
      <DocumentList />
    </div>
  );
}