'use client';

import MemberList from '@/components/members/MemberList';

export default function MembersPage() {
  return (
    <div>
      <MemberList />
    </div>
  );
}