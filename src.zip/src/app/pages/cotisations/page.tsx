'use client';

import CotisationList from '@/components/cotisations/CotisationList';

export default function CotisationsPage() {
  return (
    <div>
      <CotisationList />
    </div>
  );
}