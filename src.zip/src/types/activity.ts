export interface Activity {
  id: number;
  name: string;
  description: string;
  eventDate: string;
}