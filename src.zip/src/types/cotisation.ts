export interface Cotisation {
  id?: number;
  amount: number;
  paymentDate: string;
  memberId: number;
}