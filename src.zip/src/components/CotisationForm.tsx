'use client';

import React, { useEffect, useState } from 'react';
import { Cotisation } from '@/types/cotisation';
import { Member } from '@/types/member';
import { InputNumber } from 'primereact/inputnumber';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';

interface CotisationFormProps {
  cotisation?: Cotisation;
  onSubmit: (data: Cotisation) => Promise<void>;
  onCancel: () => void;
  members: Member[];
}

const CotisationForm: React.FC<CotisationFormProps> = ({
  cotisation,
  onSubmit,
  onCancel,
  members,
}) => {
  const [formData, setFormData] = useState<Cotisation>({
    amount: 0,
    paymentDate: new Date().toISOString().split('T')[0],
    memberId: 0,
  });

  useEffect(() => {
    if (cotisation) {
      setFormData({
        amount: cotisation.amount,
        paymentDate: cotisation.paymentDate,
        memberId: cotisation.memberId,
      });
    }
  }, [cotisation]);

  const handleChange = (field: keyof Cotisation, value: any) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="p-fluid">
      <div className="mb-3">
        <label htmlFor="amount">Amount</label>
        <InputNumber
          id="amount"
          value={formData.amount}
          onValueChange={(e) => handleChange('amount', e.value)}
          mode="currency"
          currency="MAD"
          locale="fr-MA"
          required
        />
      </div>

      <div className="mb-3">
        <label htmlFor="paymentDate">Payment Date</label>
        <Calendar
          id="paymentDate"
          value={new Date(formData.paymentDate)}
          onChange={(e) => handleChange('paymentDate', (e.value as Date).toISOString().split('T')[0])}
          showIcon
          dateFormat="yy-mm-dd"
          required
        />
      </div>

      <div className="mb-3">
        <label htmlFor="member">Member</label>
        <Dropdown
          id="member"
          value={formData.memberId}
          options={members}
          optionLabel={(m: Member) => `${m.firstName} ${m.lastName}`}
          optionValue="id"
          onChange={(e) => handleChange('memberId', e.value)}
          placeholder="Select Member"
          filter
        />
      </div>

      <div className="d-flex justify-content-end gap-2 mt-3">
        <Button label="Cancel" type="button" severity="secondary" onClick={onCancel} />
        <Button label={cotisation ? 'Update' : 'Create'} type="submit" />
      </div>
    </form>
  );
};

export default CotisationForm;