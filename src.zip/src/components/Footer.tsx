'use client';

const Footer = () => (
  <footer className="bg-dark text-white text-center py-2 mt-auto">
    <small>© 2025 Association Manager</small>
  </footer>
);

export default Footer;