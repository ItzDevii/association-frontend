import api from './api';
import { Cotisation } from '@/types/cotisation';

export const getCotisations = async (): Promise<Cotisation[]> => {
  const res = await api.get('/cotisations');
  return res.data;
};

export const createCotisation = async (data: Cotisation): Promise<Cotisation> => {
  const res = await api.post('/cotisations', {
    amount: data.amount,
    paymentDate: data.paymentDate,
    memberId: data.memberId,
  });
  return res.data;
};

export const updateCotisation = async (id: number, data: Cotisation): Promise<Cotisation> => {
  const res = await api.put(`/cotisations/${id}`, {
    amount: data.amount,
    paymentDate: data.paymentDate,
    memberId: data.memberId,
  });
  return res.data;
};

export const deleteCotisation = async (id: number): Promise<void> => {
  await api.delete(`/cotisations/${id}`);
};